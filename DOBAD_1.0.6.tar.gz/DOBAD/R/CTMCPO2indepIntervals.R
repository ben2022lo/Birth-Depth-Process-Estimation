CTMCPO2indepIntervals <- function(partialDat)
  UseMethod("CTMCPO2indepIntervals")


